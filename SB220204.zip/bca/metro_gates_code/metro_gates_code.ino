#include <SPI.h>
#include <MFRC522.h>
#include <Servo.h>
#include <Wire.h>
#include <LiquidCrystal_I2C.h>

// RFID Module Pins
#define SS_PIN 10
#define RST_PIN 9

MFRC522 rfid(SS_PIN, RST_PIN);
Servo servo1;
Servo servo2;

// LCD Display (Address 0x27, 16 columns, 2 rows)
LiquidCrystal_I2C lcd(0x27, 16, 2);

// Servo Positions
int closedPosition1 = 0;
int openPosition1 = 90;
int closedPosition2 = 180;
int openPosition2 = 90;

// ✅ Your Card UID (D2 39 1E 03)
byte authorizedUID[] = {0xD2, 0x39, 0x1E, 0x03};

void setup() {
  Serial.begin(9600);
  SPI.begin();
  rfid.PCD_Init();

  // Attach Servos
  servo1.attach(5);
  servo2.attach(6);

  // Set initial positions
  servo1.write(closedPosition1);
  servo2.write(closedPosition2);

  // Initialize LCD
  lcd.init();
  lcd.backlight();
  lcd.setCursor(0, 0);
  lcd.print("Place Your Card");

  Serial.println("System Ready – Place Your Card");
}

void loop() {
  if (!rfid.PICC_IsNewCardPresent() || !rfid.PICC_ReadCardSerial()) {
    return;
  }

  Serial.print("Card UID: ");
  for (byte i = 0; i < rfid.uid.size; i++) {
    Serial.print(rfid.uid.uidByte[i], HEX);
    Serial.print(" ");
  }
  Serial.println();

  if (isAuthorizedCard()) {
    Serial.println("Access Granted! Opening gate...");
    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print("Access Granted");
    lcd.setCursor(0, 1);
    lcd.print("Opening Gate...");

    openGate();
    delay(3000);

    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print("Gate Closing...");
    Serial.println("Gate Closing...");
    closeGate();
    
    delay(2000);
    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print("Place Your Card");
  } else {
    Serial.println("Access Denied!");
    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print("Access Denied!");
    delay(2000);
    lcd.clear();
    lcd.setCursor(0, 0);
    lcd.print("Place Your Card");
  }

  rfid.PICC_HaltA();
}

bool isAuthorizedCard() {
  if (rfid.uid.size != 4) {
    return false;
  }
  for (byte i = 0; i < 4; i++) {
    if (rfid.uid.uidByte[i] != authorizedUID[i]) {
      return false;
    }
  }
  return true;
}

void openGate() {
  servo1.write(openPosition1);
  servo2.write(openPosition2);
  Serial.println("Gate Opened!");
}

void closeGate() {
  servo1.write(closedPosition1);
  servo2.write(closedPosition2);
  Serial.println("Gate Closed!");
}
